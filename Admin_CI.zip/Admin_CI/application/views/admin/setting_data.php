<!DOCTYPE html>
<html lang="en">

  <head>

<title>Admin - Dashboard</title>

<!-- Bootstrap core CSS-->
<?php echo link_tag('assests/vendor/bootstrap/css/bootstrap.min.css'); ?>
<!-- Custom fonts for this template-->
<?php echo link_tag('assests/vendor/fontawesome-free/css/all.min.css'); ?>
<!-- Page level plugin CSS-->
<?php echo link_tag('assests/vendor/datatables/dataTables.bootstrap4.css'); ?>
<!-- Custom styles for this template-->
<?php echo link_tag('assests/css/sb-admin.css'); ?>

  </head>

  <body id="page-top">
       <?php include APPPATH.'views/admin/includes/header.php';?>


    <div id="wrapper">

      <!-- Sidebar -->
            <?php include APPPATH.'views/admin/includes/sidebar.php';?>
      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Overview</li>
          </ol>

          <!-- Icon Cards-->
          
          <!-- Tab links -->
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <style>
            body {font-family: Arial;}

  /*----------------------------------------------- Style the tab ------------------------------------------*/
            .tab {
              overflow: hidden;
              border: 1px solid #ccc;
              background-color: #f1f1f1;
            }

            /* Style the buttons inside the tab */
            .tab button {
              background-color: inherit;
              float: left;
              border: none;
              outline: none;
              cursor: pointer;
              padding: 14px 16px;
              transition: 0.3s;
              font-size: 17px;
            }

            /* Change background color of buttons on hover */
            .tab button:hover {
              background-color: #ddd;
            }

            /* Create an active/current tablink class */
            .tab button.active {
              background-color: #ccc;
            }

            /* Style the tab content */
            .tabcontent {
              display: none;
              padding: 6px 12px;
              border: 1px solid #ccc;
              border-top: none;
            }
            </style>
             
 <!------------------------------------- /.Setting html Page ------------------------------------------------------------>
            <h2>CMS UPDATE</h2>
            <p>Click on the buttons inside the tabbed menu:</p>

            <div class="tab">
              <button class="tablinks" onclick="openCity(event, 'Home')">Home</button>
              <button class="tablinks" onclick="openCity(event, 'Ecosystem')">Ecosystem</button>
              <button class="tablinks" onclick="openCity(event, 'Fan App')">Fan App</button>
              <button class="tablinks" onclick="openCity(event, 'Marketplace')">Marketplace</button>
              <button class="tablinks" onclick="openCity(event, 'Data Anlaytics')">Data Anlaytics</button>
              <button class="tablinks" onclick="openCity(event, 'Contact')">Contact</button>
              <button class="tablinks" onclick="openCity(event, 'FAQ')">FAQ</button>
             
            </div>

            <div id="Home" class="tabcontent">
                  <h3>Home</h3>
         
                  <div style="color:red">
                    <?php echo validation_errors(); ?>
                    <?php if(isset($error)){print $error;}?>
                  </div>
                  <?php echo form_open_multipart('admin/Setting_Update/home_data');?>
      <?php if(isset($home_list)){?>
      <?php if(count($home_list)){?>
     
        <?php foreach ($home_list as $pic): ?>  
                    <div class="form-group">
                      <label for="pic_title">Picture Title*:</label>
                      <input type="text" class="form-control" name="pic_title" value="<?=$pic->pic_title;?>" id="pic_title" required>
                    </div>
                    <div class="form-group">
                      <label for="pic_desc">Picture Description:</label>
                      <textarea name="pic_desc" class="form-control" id="pic_desc"><?=$pic->pic_desc;?></textarea>
                    </div>
                    <!-- <div class="form-group">
                      <label for="pic_file">Select Image*:</label>
                      <input type="file" name="pic_file" class="form-control"  id="pic_file">
                    </div> -->
                    <a href="<?=base_url();?>" class="btn btn-warning">Back</a>
                    <button type="submit" class="btn btn-success">UPDATE</button>
        <?php endforeach ?>
        <?php } } ?>
                  </form>
            </div>

<!-----------------------------------------------------Ecosystem--------------------------------------------------------->

<div id="Ecosystem" class="tabcontent">
  <h3>Ecosystem</h3>
  <div style="color:red">
        <?php echo validation_errors(); ?>
        <?php if(isset($error)){print $error;}?>
      </div>
      <?php echo form_open_multipart('admin/Setting_Update/ecosystem_data/');?>

    <?php if(isset($ecosystem_list)){?>
      <?php if(count($ecosystem_list)){?>
        <?php foreach ($ecosystem_list as $eco_pic): //echo "<pre>"; print_r($eco_pic) ?>  
        
          <div class="form-group">
            <label for="pic_title">First Picture Title*:</label>
            <input type="text" class="form-control" name="first_pic_title" value="<?=$eco_pic->first_pic_title;?>" id="first_pic_title">
          </div>
          <div class="form-group">
            <label for="pic_file">First Select Image*:</label>
            <input type="file" name="first_pic_file" class="form-control"  id="pic_file">
            <input type="hidden" name="first_old" value="<?=$eco_pic->first_pic_file;?>">
            <img src="<?=base_url().'assests/uploads/'.$eco_pic->first_pic_file;?>" width="100">
          </div>
          <div class="form-group">
            <label for="pic_title">Second Picture Title*:</label>
            <input type="text" class="form-control" name="second_pic_title" value="<?=$eco_pic->second_pic_title;?>" id="second_pic_title">
          </div>
          <div class="form-group">
            <label for="pic_file">Second Select Image*:</label>
            <input type="file" name="second_pic_file" class="form-control"  id="second_pic_file">
            <input type="hidden" name="second_old" value="<?=$eco_pic->second_pic_file;?>">
            <img src="<?=base_url().'assests/uploads/'.$eco_pic->second_pic_file;?>" width="100">
          </div>
          <div class="form-group">
            <label for="pic_title">Third Picture Title*:</label>
            <input type="text" class="form-control" name="third_pic_title" value="<?=$eco_pic->third_pic_title;?>" id="third_pic_title">
          </div>
          <div class="form-group">
            <label for="pic_file">Third Select Image*:</label>
            <input type="file" name="third_pic_file" class="form-control"  id="third_pic_file">
            <input type="hidden" name="third_old" value="<?=$eco_pic->third_pic_file;?>">
            <img src="<?=base_url().'assests/uploads/'.$eco_pic->third_pic_file;?>" width="100">
          </div>
          <div class="form-group">
            <label for="pic_title">Four Picture Title*:</label>
            <input type="text" class="form-control" name="fourth_pic_title" value="<?=$eco_pic->fourth_pic_title;?>" id="fourth_pic_title">
          </div>
          <div class="form-group">
            <label for="pic_file"> Four Select Image*:</label>
            <input type="file" name="fourth_pic_file" class="form-control"  id="fourth_pic_file">
            <input type="hidden" name="fourth_old" value="<?=$eco_pic->fourth_pic_file;?>">
            <img src="<?=base_url().'assests/uploads/'.$eco_pic->fourth_pic_file;?>" width="100">
          </div>

          <a href="<?=base_url();?>" class="btn btn-warning">Back</a>
          <button type="submit" class="btn btn-success">UPDATE</button>
        <?php endforeach ?>
        <?php } } ?>
          </form>
    </div>
     
  </div>

<!-----------------------------------------------------Fan App--------------------------------------------------------->
            <div id="Fan App" class="tabcontent">
              <h3>Fan App</h3>
              
                    
                  <div style="color:red">
                    <?php echo validation_errors(); ?>
                    <?php if(isset($error)){print $error;}?>
                  </div>
                  <?php echo form_open_multipart('admin/Setting_Update/fun_data');?>
  <?php if(isset($fan_app_list)){?>
      <?php if(count($fan_app_list)){?>
        <?php foreach ($fan_app_list as $fan_pic): //echo "<pre>"; print_r($fan_pic) ?>    


                    <div class="form-group">
                      <label for="pic_title">Picture Title*:</label>
                      <input type="text" class="form-control" name="fan_pic_title" value="<?=$fan_pic->fan_pic_title;?>" id="fan_pic_title" required>
                    </div>
                    <div class="form-group">
                      <label for="pic_desc">Picture Description:</label>
                      <textarea name="fan_pic_desc" class="form-control" id="fan_pic_desc"><?=$fan_pic->fan_pic_desc;?></textarea>
                    </div>
                    <div class="form-group">
                      <label for="pic_file">Select Image*:</label>
                      <input type="file" name="first_pic_file" class="form-control"  id="pic_file">
                      <input type="hidden" name="fan_first_old" value="<?=$fan_pic->first_pic_file;?>">
                      <img src="<?=base_url().'assests/uploads/'.$fan_pic->first_pic_file;?>" width="100">
                    </div>
                    
                    <div class="form-group">
                      <label for="pic_file">Select Image*:</label>
                      <input type="file" name="second_pic_file" class="form-control"  id="second_pic_file">
                      <input type="hidden" name="fan_second_old" value="<?=$fan_pic->second_pic_file;?>">
                      <img src="<?=base_url().'assests/uploads/'.$fan_pic->second_pic_file;?>" width="100">
                    </div>
                    <div class="form-group">
                      <label for="pic_file">Select Image*:</label>
                      <input type="file" name="third_pic_file" class="form-control"  id="third_pic_file">
                      <input type="hidden" name="fan_third_old" value="<?=$fan_pic->third_pic_file;?>">
                      <img src="<?=base_url().'assests/uploads/'.$fan_pic->third_pic_file;?>" width="100">
                    </div>
                    <div class="form-group">
                      <label for="pic_file">Select Image*:</label>
                      <input type="file" name="fourth_pic_file" class="form-control"  id="fourth_pic_file">
                      <input type="hidden" name="fan_fourth_old" value="<?=$fan_pic->fourth_pic_file;?>">
                      <img src="<?=base_url().'assests/uploads/'.$fan_pic->fourth_pic_file;?>" width="100">
                    </div>
                    
                    <a href="<?=base_url();?>" class="btn btn-warning">Back</a>
                    <button type="submit" class="btn btn-success">Submit</button>

    <?php endforeach ?>
        <?php } } ?>
          </form>
            </div>
           

<!-----------------------------------------------------Market Place--------------------------------------------------------->



  <div id="Marketplace" class="tabcontent">
              <h3>Marketplace</h3>
               <div style="color:red">
                    <?php echo validation_errors(); ?>
                    <?php if(isset($error)){print $error;}?>
                  </div>
                  <?php echo form_open_multipart('admin/Setting_Update/market_data');?>
      <?php if(isset($market_list)){?>
      <?php if(count($market_list)){?>
     
        <?php foreach ($market_list as $market_pic): ?>  
              <div class="form-group">
                <label for="pic_title">First Picture Title*:</label>
                <input type="text" class="form-control" name="first_pic_title" value="<?=$market_pic->first_pic_title;?>" id="first_pic_title" required>
              </div>
              <div class="form-group">
                <label for="pic_title">First Picture heading*:</label>
                <input type="text" class="form-control" name="first_pic_heading" value="<?=$market_pic->first_pic_heading;?>" id="first_pic_heading" required>
              </div>
              <div class="form-group">
                <label for="pic_desc">First Picture Description:</label>
                <textarea name="first_pic_desc" class="form-control" id="first_pic_desc"><?=$market_pic->first_pic_desc;?></textarea>
              </div>
              <div class="form-group">
                <label for="pic_file">First Select Image*:</label>
                <input type="file" name="first_pic_file" class="form-control"  id="first_pic_file">
                <input type="hidden" name="market_first_old" value="<?=$market_pic->first_pic_file;?>">
                <img src="<?=base_url().'assests/uploads/'.$market_pic->first_pic_file;?>" width="100">
              </div>
              <div class="form-group">
                <label for="pic_file">Second Select Image*:</label>
                <input type="file" name="second_pic_file" class="form-control"  id="second_pic_file">
                <input type="hidden" name="market_second_old" value="<?=$market_pic->second_pic_file;?>">
                <img src="<?=base_url().'assests/uploads/'.$market_pic->second_pic_file;?>" width="100">
              </div>
              <div class="form-group">
                <label for="pic_title">Second Picture heading*:</label>
                <input type="text" class="form-control" name="second_pic_heading" value="<?=$market_pic->second_pic_heading;?>" id="second_pic_heading" required>
              </div>
              <div class="form-group">
                <label for="pic_desc">Second Picture Description:</label>
                <textarea name="second_pic_desc" class="form-control" id="second_pic_desc"><?=$market_pic->second_pic_desc;?></textarea>
              </div>
              <div class="form-group">
                <label for="pic_file">Third Select Image*:</label>
                <input type="file" name="third_pic_file" class="form-control"  id="third_pic_file">
                <input type="hidden" name="market_third_old" value="<?=$market_pic->third_pic_file;?>">
                <img src="<?=base_url().'assests/uploads/'.$market_pic->third_pic_file;?>" width="100">
              </div>
              <div class="form-group">
                <label for="pic_title">Third Picture heading*:</label>
                <input type="text" class="form-control" name="third_pic_heading" value="<?=$market_pic->third_pic_heading;?>" id="third_pic_heading" required>
              </div>
              <div class="form-group">
                <label for="pic_desc">Third Picture Description:</label>
                <textarea name="third_pic_desc" class="form-control" id="third_pic_desc"><?=$market_pic->third_pic_desc;?></textarea>
              </div>

              <div class="form-group">
                <label for="pic_file">Fourth Select Image*:</label>
                <input type="file" name="fourth_pic_file" class="form-control"  id="fourth_pic_file">
                <input type="hidden" name="market_fourth_old" value="<?=$market_pic->fourth_pic_file;?>">
                <img src="<?=base_url().'assests/uploads/'.$market_pic->fourth_pic_file;?>" width="100">
              </div>
              <div class="form-group">
                <label for="pic_title"> Fourth Picture heading*:</label>
                <input type="text" class="form-control" name="fourth_pic_heading" value="<?=$market_pic->fourth_pic_heading;?>" id="fourth_pic_heading" required>
              </div>
              <div class="form-group">
                <label for="pic_desc">Fourth Picture Description:</label>
                <textarea name="fourth_pic_desc" class="form-control" id="fourth_pic_desc"><?=$market_pic->fourth_pic_desc;?></textarea>
              </div>
              <div class="form-group">
                <label for="pic_file">Fifth Select Image*:</label>
                <input type="file" name="fifth_pic_file" class="form-control"  id="fifth_pic_file">
                <input type="hidden" name="markrt_fifth_old" value="<?=$market_pic->fifth_pic_file;?>">
                <img src="<?=base_url().'assests/uploads/'.$market_pic->fifth_pic_file;?>" width="100">
              </div>
              <div class="form-group">
                <label for="pic_title">Fifth Picture heading*:</label>
                <input type="text" class="form-control" name="fifth_pic_heading" value="<?=$market_pic->fifth_pic_heading;?>" id="third_pic_heading" required>
              </div>
              <div class="form-group">
                <label for="pic_desc">Fifth Picture Description:</label>
                <textarea name="fifth_pic_desc" class="form-control" id="fifth_pic_desc"><?=$market_pic->fifth_pic_desc;?></textarea>
              </div>

              <a href="<?=base_url();?>" class="btn btn-warning">Back</a>
              <button type="submit" class="btn btn-success">UPDATE</button>
        <?php endforeach ?>
        <?php } } ?>
                  </form>
              
  </div>


<!--------------------------------------------------Data Anlaytics----------------------------------------------------------->

    <div id="Data Anlaytics" class="tabcontent">
        <h3>Data Anlaytics</h3>
          <div style="color:red">
                    <?php echo validation_errors(); ?>
                    <?php if(isset($error)){print $error;}?>
                  </div>
                  <?php echo form_open_multipart('admin/Setting_Update/dataAnlaytics');?>
  <?php if(isset($data_anlaytics_list)){?>
      <?php if(count($data_anlaytics_list)){?>
        <?php foreach ($data_anlaytics_list as $data_pic): //echo "<pre>"; print_r($fan_pic) ?>    


                    <div class="form-group">
                      <label for="pic_title">First Picture Title*:</label>
                      <input type="text" class="form-control" name="first_pic_title" value="<?=$data_pic->first_pic_title;?>" id="first_pic_title" required>
                    </div>
                    <div class="form-group">
                      <label for="pic_title">First Picture heading*:</label>
                      <input type="text" class="form-control" name="first_pic_heading" value="<?=$data_pic->first_pic_heading;?>" id="first_pic_heading" required>
                    </div>
                    <div class="form-group">
                      <label for="pic_desc">First Picture Description:</label>
                      <textarea name="first_pic_desc" class="form-control" id="first_pic_desc"><?=$data_pic->first_pic_desc;?></textarea>
                    </div>
                    <div class="form-group">
                      <label for="pic_file">First Select Image*:</label>
                      <input type="file" name="first_pic_file" class="form-control"  id="pic_file">
                      <input type="hidden" name="data_first_old" value="<?=$data_pic->first_pic_file;?>">
                      <img src="<?=base_url().'assests/uploads/'.$data_pic->first_pic_file;?>" width="100">
                    </div>
                    
                    <div class="form-group">
                      <label for="pic_file">Second Select Image*:</label>
                      <input type="file" name="second_pic_file" class="form-control"  id="second_pic_file">
                      <input type="hidden" name="data_second_old" value="<?=$data_pic->second_pic_file;?>">
                      <img src="<?=base_url().'assests/uploads/'.$data_pic->second_pic_file;?>" width="100">
                    </div>
                    <div class="form-group">
                      <label for="pic_file">Third Select Image*:</label>
                      <input type="file" name="third_pic_file" class="form-control"  id="third_pic_file">
                      <input type="hidden" name="data_third_old" value="<?=$data_pic->third_pic_file;?>">
                      <img src="<?=base_url().'assests/uploads/'.$data_pic->third_pic_file;?>" width="100">
                    </div>

                    <div class="form-group">
                      <label for="pic_title">Second Picture Title*:</label>
                      <input type="text" class="form-control" name="second_pic_title" value="<?=$data_pic->second_pic_title;?>" id="second_pic_title" required>
                    </div>
                    <div class="form-group">
                      <label for="pic_title">secondPicture heading*:</label>
                      <input type="text" class="form-control" name="second_pic_heading" value="<?=$data_pic->second_pic_heading;?>" id="second_pic_heading" required>
                    </div>
                    <div class="form-group">
                      <label for="pic_file">Fourth Select Image*:</label>
                      <input type="file" name="fourth_pic_file" class="form-control"  id="fourth_pic_file">
                      <input type="hidden" name="data_fourth_old" value="<?=$data_pic->fourth_pic_file;?>">
                      <img src="<?=base_url().'assests/uploads/'.$data_pic->fourth_pic_file;?>" width="100">
                    </div>
                    
                    <div class="form-group">
                      <label for="pic_title">Third Picture heading*:</label>
                      <input type="text" class="form-control" name="third_pic_heading" value="<?=$data_pic->third_pic_heading;?>" id="third_pic_heading" required>
                    </div>
                    <div class="form-group">
                      <label for="pic_desc">Third Picture Description:</label>
                      <textarea name="third_pic_desc" class="form-control" id="third_pic_desc"><?=$data_pic->third_pic_desc;?></textarea>
                    </div>
                    <div class="form-group">
                      <label for="pic_title">fourth Picture heading*:</label>
                      <input type="text" class="form-control" name="fourth_pic_heading" value="<?=$data_pic->fourth_pic_heading;?>" id="fourth_pic_heading" required>
                    </div>
                    <div class="form-group">
                      <label for="pic_desc">Fourth Picture Description:</label>
                      <textarea name="fourth_pic_desc" class="form-control" id="fourth_pic_desc"><?=$data_pic->third_pic_desc;?></textarea>
                    </div>
                    <div class="form-group">
                      <label for="pic_title">Fifth Picture heading*:</label>
                      <input type="text" class="form-control" name="fifth_pic_heading" value="<?=$data_pic->fifth_pic_heading;?>" id="fifth_pic_heading" required>
                    </div>
                    <div class="form-group">
                      <label for="pic_desc">Fifth Picture Description:</label>
                      <textarea name="fifth_pic_desc" class="form-control" id="fifth_pic_desc"><?=$data_pic->fifth_pic_desc;?></textarea>
                    </div>


                    
                    <a href="<?=base_url();?>" class="btn btn-warning">Back</a>
                    <button type="submit" class="btn btn-success">Submit</button>

    <?php endforeach ?>
        <?php } } ?>
          </form>
            </div>
                
<!--------------------------------------------------Contact------------------------------------------------------------------->

   <div id="Contact" class="tabcontent">
          <h3>Contact</h3>
            <div style="color:red">
                    <?php echo validation_errors(); ?>
                    <?php if(isset($error)){print $error;}?>
                  </div>
                  <?php echo form_open_multipart('admin/Setting_Update/contact');?>
  <?php if(isset($contact_list)){?>
      <?php if(count($contact_list)){?>
        <?php foreach ($contact_list as $contact_pic): //echo "<pre>"; print_r($fan_pic) ?>    

                  <div class="form-group">
                    <label for="pic_title">Contact Title*:</label>
                    <input type="text" class="form-control" name="first_title" value="<?=$contact_pic->first_title;?>" id="first_pic_title" required>
                  </div>
                  
                  <div class="form-group">
                    <label for="pic_desc">First Description:</label>
                    <textarea name="first_desc" class="form-control" id="first_pic_desc"><?=$contact_pic->first_desc;?></textarea>
                  </div>
                  <a href="<?=base_url();?>" class="btn btn-warning">Back</a>
                  <button type="submit" class="btn btn-success">Submit</button>

    <?php endforeach ?>
        <?php } } ?>
          </form>
            </div>
              


<!----------------------------------------------------------FAQ-------------------------------------------------------------->

     <div id="FAQ" class="tabcontent">
          <h3>FAQ</h3>
             <div style="color:red">
                    <?php echo validation_errors(); ?>
                    <?php if(isset($error)){print $error;}?>
                  </div>
                  <?php echo form_open_multipart('admin/Setting_Update/faq');?>
  <?php if(isset($faq_list)){?>
      <?php if(count($faq_list)){?>
        <?php foreach ($faq_list as $faq_pic): //echo "<pre>"; print_r($fan_pic) ?>    

                  <div class="form-group">
                    <label for="pic_title">First Title*:</label>
                    <input type="text" class="form-control" name="first_title" value="<?=$faq_pic->first_title;?>" id="first_pic_title" required>
                  </div>
                  
                  <div class="form-group">
                    <label for="pic_desc">First Description:</label>
                    <textarea name="first_desc" class="form-control" id="first_desc"><?=$faq_pic->first_desc;?></textarea>
                  </div>

                  <div class="form-group">
                    <label for="pic_title">Second Title*:</label>
                    <input type="text" class="form-control" name="second_title" value="<?=$faq_pic->second_title;?>" id="second_title" required>
                  </div>
                  
                  <div class="form-group">
                    <label for="pic_desc">Second Description:</label>
                    <textarea name="second_desc" class="form-control" id="second_desc"><?=$faq_pic->second_desc;?></textarea>
                  </div>

                  <div class="form-group">
                    <label for="pic_title">Third Title*:</label>
                    <input type="text" class="form-control" name="third_title" value="<?=$faq_pic->third_title;?>" id="first_pic_title" required>
                  </div>
                  
                  <div class="form-group">
                    <label for="pic_desc">Third Description:</label>
                    <textarea name="third_desc" class="form-control" id="third_desc"><?=$faq_pic->third_desc;?></textarea>
                  </div>

                  <div class="form-group">
                    <label for="pic_title">Fourth Title*:</label>
                    <input type="text" class="form-control" name="fourth_title" value="<?=$faq_pic->fourth_title;?>" id="four_title" required>
                  </div>
                  
                  <div class="form-group">
                    <label for="pic_desc">Four Description:</label>
                    <textarea name="fourth_desc" class="form-control" id="fourth_desc"><?=$faq_pic->fourth_desc;?></textarea>

                    <div class="form-group">
                    <label for="pic_title">Fifth Title*:</label>
                    <input type="text" class="form-control" name="fifth_title" value="<?=$faq_pic->fifth_title;?>" id="first_pic_title" required>
                  </div>
                  
                  <div class="form-group">
                    <label for="pic_desc">Fifth Description:</label>
                    <textarea name="fifth_desc" class="form-control" id="fifth_desc"><?=$faq_pic->fifth_desc;?></textarea>
                  </div>

                  </div>
                  <a href="<?=base_url();?>" class="btn btn-warning">Back</a>
                  <button type="submit" class="btn btn-success">Submit</button>

    <?php endforeach ?>
        <?php } } ?>
          </form>
            </div>
              
   </div>
              
     </div>


<!------------------------------------- /.Script. js ------------------------------------------------------------------>
            <script>
            function openCity(evt, cityName) {
              var i, tabcontent, tablinks;
              tabcontent = document.getElementsByClassName("tabcontent");
              for (i = 0; i < tabcontent.length; i++) {
                tabcontent[i].style.display = "none";
              }
              tablinks = document.getElementsByClassName("tablinks");
              for (i = 0; i < tablinks.length; i++) {
                tablinks[i].className = tablinks[i].className.replace(" active", "");
              }
              document.getElementById(cityName).style.display = "block";
              evt.currentTarget.className += " active";
            }
            </script>
               
            





        <!-- /.container-fluid -->

        <!-- Sticky Footer -->
        <?php include APPPATH.'views/admin/includes/footer.php';?>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>


    <script src="<?php echo base_url('assests/vendor/jquery/jquery.min.js'); ?>"></script>
    <script src="<?php echo base_url('assests/vendor/bootstrap/js/bootstrap.bundle.min.js'); ?>"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url('assests/vendor/jquery-easing/jquery.easing.min.js'); ?>"></script>

    <!-- Page level plugin JavaScript-->
    <script src="<?php echo base_url('assests/vendor/chart.js/Chart.min.js'); ?>"></script>
    <script src="<?php echo base_url('assests/vendor/datatables/jquery.dataTables.js'); ?>"></script>
    <script src="<?php echo base_url('assests/vendor/datatables/dataTables.bootstrap4.js'); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo base_url('assests/js/sb-admin.min.js'); ?>"></script>
    <script src="<?php echo base_url('assests/js/demo/datatables-demo.js'); ?>"></script>
    <script src="<?php echo base_url('assests/js/demo/chart-area-demo.js'); ?>"></script>

  </body>

</html>
