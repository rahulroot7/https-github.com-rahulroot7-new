<?php
    $con=mysqli_connect("localhost","root","","LMS");

    if(mysqli_connect_errno())
    {
    	echo "Cannot connect to mysqli:" . mysqli_connect_error();
    }
?>