<?php
defined('BASEPATH') OR exit('No direct script access allowed');
Class Home extends CI_Controller {
function __construct(){
parent::__construct();
if(! $this->session->userdata('adid'))
redirect('admin/login');
}


	public function index()
		{
			$this->load->model('Update_model');

			$data['home_list'] = $this->Update_model->get_home_pics();
			// $data['ecosystem_list'] = $this->Update_model->get_ecosystem_pics();
			// print_r($data['ecosystem_list']);die;
			$this->load->view('admin/Content', $data);
			
		}
	
}