<?php
    session_start();
?>

<?php
        include "config.php";

        $f_name_error = $l_name_error = $email_error = $pass_error = $s_error = "";
        $f_name = $l_name = $email = $pass = $s = "";
        function test_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
    if(isset($_POST['submit']))
    {

        if(empty($_POST['name'])){
            $f_name_error = 'Name Required';
        }else{
            $f_name = test_input($_POST["name"]);
        }
        if(empty($_POST['lname'])){
            $l_name_error ='Last Name Required';
        } else{
            $l_name = test_input($_POST['lname']);
        }
        if(empty($_POST['email'])){
            $email_error = ' Required';
        }else{
            $email = test_input($_POST["email"]);
        } 
        if(empty($_POST['pass'])){
            $pass_error = 'Password Required';
        }else{
            $pass = test_input(md5($_POST["pass"]));
        }  
        if(isset($_POST['sb'])){
            $s = $_POST['sb'];           
        }
        
        
        // print_r($email);die;
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        if ($email != '' && $f_name != '' && $l_name != '' && $pass != '' && $s != '') {

            $sel = mysqli_query($con, "select *from student where email = '$email' ");
     
                if (mysqli_num_rows($sel) > 0) {
                    $msg = "<div class='btn btn-success'>Email Already Registered</div>";
                    
                }else{
                    $chk = '';
                    $i = 0;
                    foreach($s as $value){
                        $i++;
                        //  print_r($value);die;
                        if(count($s) == $i ){
                            $chk.= $value; 
                        }else{
                            $chk.= $value.",";
                        }  
                    }

                    $sql = "INSERT INTO student(Firstname, Lastname,email,pass,Subject) VALUES('$f_name','$l_name','$email','$pass','$chk')";

                    if (mysqli_query($con,$sql))
                    {
                        $_SESSION["email"] = $email;
                        $_SESSION["pass"] = $pass;   
                        $msg = "<div class='btn btn-success'>Registration successfull</div>";
                        // header('location:stuprofile.php');
                    }else{
                        "<div class='btn btn-danger'>Registration not successfull</div>";
                    }
                }
        
        }else{
            $empty = "<div class='btn btn-danger'>empty field required</div><br>";
        }
        }else{
            $mail = "<div class='error'>Email Not Valid</div><br>";
        }


   
}
?>


<!DOCTYPE>
<html>
<head>
    <title></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="css/style.css">
    <style>
        .error {color: #FF0000;};

    </style>
</head>

<body>

    <h1>  Student Registeration </h1>
    
    <form name="form1" method="post" action="registration.php" >
    <fieldset>
    <legend> Registration Form 
       
        <a style="padding-left:750px"href="index.php">HOME</a>
        
    </legend> 
    <?php
    if(isset($msg)){

        echo $msg;
    }
    ?><br>

    FirstName <input type="text" name="name" value=""/>
    <span class="error">*<?php echo $f_name_error;?></span><br>
    <br/><br/>
    LastName <input type="text" name="lname" value=""/>
    <span class="error">*<?php echo $l_name_error;?></span><br>
    <br/><br/>
    Email <input type="text" name="email" value=""/>
    <span class="error">*<?php echo $email_error;?></span><br>
    <?php

    if(isset($mail)){

        echo $mail;
    }
    ?>
    <br/><br/>
    Password <input type="password" name="pass" value=""/>
    <span class="error">*<?php echo $pass_error;?></span><br>
    <br/><br/>

    <h3> Subject selection </h3> <span class="error"><?php echo $email_error;?></span><br>
    <input type="checkbox" name="sb[]" value="php"/> PHP 
    <br/>
    <input type="checkbox" name="sb[]" value="asp"/> ASP.NET 
    <br/>
    <input type="checkbox" name="sb[]" value="html"/> HTML 
    <br/>
    <input type="checkbox" name="sb[]" value="css"/> CSS 
    <br/><br/>
    <input type="submit" name="submit" value="Submit"/><button ><a href="login.php"> Login</a></button><div>
    </fieldset>
    <?php

    if(isset($empty)){

        echo $empty."<br>";
    }
    ?>
    </form>

   
</body>
</html>