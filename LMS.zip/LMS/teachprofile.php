<?php
    if(isset($_POST['fee'])){
        $number = $_POST['fee'];
       // print_r($number);
    }
    if(isset($_POST['id'])){
         $id = $_POST['id'];
         // print_r($id);
     }
      
    

    include 'config.php';
    
    if(!empty($number)){
       
    $sql = "UPDATE fee_record SET fee = '{$number}' WHERE id= '$id'";
    if(mysqli_query($con,$sql)){
    
    $result = mysqli_query($con, $sql) or die("Query Unsuccessful.");
    }
    $msg = "<div class='btn btn-success'> Update successfull</div>";
    //header("Location: teachprofile.php");
    

    }else{
        
        
    }

    mysqli_close($con);

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <title></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="css/style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <style>
       table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 75%;
            }

            td, th {
            border: 1px solid pink;
            text-align: left;
            padding: 8px;
            }

            tr:nth-child(even) {
            background-color: lightblue;
            }
    </style>

</head>
<body>
    



<?php
    session_start();


    if (!isset($_SESSION["email"])) {
        header("location: login.php");
    }
    ?>

        <div style="padding-left:1200px"><br>
    
            <button><a href="logout.php">LOGOUT</a></button>
          
        </div>
        <?php
                include'config.php';  

                $email = $_SESSION["email"];
                $password = $_SESSION["pass"];
                      
               $result = mysqli_query($con, "select * from teacher where temail='$email'");
                if(mysqli_num_rows($result) > 0){
        ?>
                <?php
                    while($row = mysqli_fetch_assoc($result)){
                         $tsub = $row['tsubject'];
                ?>
                        <div style="padding-left:50px">
                    <?php
                            if(isset($msg)){

                                echo $msg;
                            }
                    ?><br>
                        <h2>WELCOME:<?php echo $row['tFirstname']; ?><?php echo $row['tLastname']; ?></h2>
                <?php
                    }
                ?>  
            </div>
            <div style="padding-left:80px">
            <h5> Your Select Subject </h5>
                    <?php
                             echo "<br>".$tsub."<br>";
                    ?>  
                <br/><br/>
                <h3> Course Fee Details </h3><br> 
                <table bprder = '1'>
                <thead>
                <th>Course</th>
                <th>Teacher Name</th>
                <th>Student Name</th>
                <th>message</th>
                <th>Fee</th>
                <th>Course Fee</th>

               
            <?php
                $join  = mysqli_query($con,"select * from fee_record");
                     if(mysqli_num_rows($join) > 0){

                        ?>
                        <?php

                            while($row = mysqli_fetch_array($join)){
                                $f_sub = $row['subject_id'];

                                if($tsub == $f_sub){
                                   
                             ?> 
                                    <tr>
                                    <form  action="teachprofile.php" method="post" enctype="multipart/form-data">
                                        <input type="hidden" name="id" value="<?php echo $row['id']?>"/>
                                        <td><?php echo $row['subject_id']; ?></td>
                                        <td><?php echo $row['teacher_name']; ?></td>
                                        <td><?php echo $row['student_name']; ?></td>
                                        <td><?php echo $row['message'];?></td>
                                        <td><?php echo $row['fee']; ?></td>
                                        <td> Course Fee  :<input type="number" name = 'fee' value=""><br>
                                        <input type ="submit" name = "submit"></td>
                                    </form>

                                <?php
                                
                               }
                            }   

                        ?>
                            
                    </th>


                    <?php
                   }  
        }
        

      mysqli_close($con);
?></tbody> </table> 


</body>
</html>