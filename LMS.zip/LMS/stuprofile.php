<?php

    if(isset($_POST['submit']))
    {
        if(isset($_POST['s_sub'])){
            $s_sub = $_POST['s_sub'];
        }
        if(isset($_POST['s_name'])){
            $s_name = $_POST['s_name'];
        }
        if(isset($_POST['t_name'])){
            $t_name = $_POST['t_name'];
        }
        if(isset($_POST['t_fee'])){
             $t_fee = $_POST['t_fee'];
        }
        if(isset($_POST['msg'])){
             $msg = $_POST['msg'];
            
        }


         include 'config.php';
        
        
           
        $sql = "INSERT INTO fee_record(subject_id,teacher_name,student_name,message,fee) VALUES ('$s_sub','$t_name','$s_name','$msg','$t_fee')";
         // print_r($sql);die;
        if(mysqli_query($con,$sql)){
          $messg = "<div class='btn btn-success'>successfull</div>";
          // header("Location: stuprofile.php");
        }
        else{
             echo "Query Unsuccessful.";
        }
    

    mysqli_close($con);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Popper JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="css/style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="css/style.css">
    
    <style>
       table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 75%;
            }

            td, th {
            border: 1px solid pink;
            text-align: left;
            padding: 8px;
            }

            tr:nth-child(even) {
            background-color: lightblue;
            }
    </style>

</head>
<body>
    



<?php
session_start();


if (!isset($_SESSION["email"])) {
    header("location: login.php");
}
?>

    <div style="padding-left:1200px"><br>
    
        <button><a href="logout.php">LOGOUT</a></button>
      
    </div>
    <?php
            include'config.php';  

            $email = $_SESSION["email"];
            $password = $_SESSION["pass"];
                  
           $result = mysqli_query($con, "select * from student where email='$email'");
        //    print_r($result);
            $teacher_data = mysqli_query($con,"SELECT * FROM teacher");
            $arr = [];

            while($teacher_d = mysqli_fetch_array($teacher_data)){
                $arr[]=$teacher_d;
                // echo "<pre>";
                // print_r($arr);die;
            }
    
      if(mysqli_num_rows($result) > 0){
        ?>
        <?php
            while($row = mysqli_fetch_assoc($result)){      
                $sub = $row['subject'];    
                $subbb1 = explode(",",$sub);
                    //  print_r($subbb1);
                     
        ?>
             
                <div style="padding-left:50px">
                <?php
                        if(isset($messg)){

                            echo $messg;
                        }
                ?>  
                <h2>WELCOME:<?php echo $row['Firstname']; ?><?php echo " ".$row['Lastname']; ?></h2>
                </div>
                <div style="padding-left:80px">
                <h5> Student Select Subject </h5>
                <div style="padding-left:80px">
                <table bprder = '1'>
                <thead>
                    <th>Subject Name</th>
                    <th>Teacher Name</th>
                    <th>Course Fee</th> 
                    <th>Message for teacher</th>
                    <th>Save</th>
                   

                        <?php
                            
                            foreach($subbb1 as $av)
                            {
                        ?>
                                <form name="form1" method="post" action="stuprofile.php" > 
                                <input type="hidden" name="s_name" value="<?php echo $row['Firstname']; ?>"/>

                        
                                    <tr>
                                     <?php echo "<td>$av</td>" ?>
                                    <input type="hidden" name="s_sub" value="<?php echo $av; ?>"/>
                        <?php
                                     echo "<td><select name='t_name'>";

                                     foreach ($arr as $teacher_subject) {

                                        if ($av == $teacher_subject['tsubject']) {
                                           
                                            echo "<option>".$teacher_subject['tFirstname']. "</option></br>";

                                        }                         
                                    }
                                    echo "</select>";
                                    echo "<td><select name='t_fee'>";

                                     foreach ($arr as $teacher_subject) {

                                        if ($av == $teacher_subject['tsubject']) {
                                           
                                            echo "<option>".$teacher_subject['fee']. "</option></br>";
                                            
                                        }                         
                                    }
                                    echo "</select>";
                                  echo "<td><textarea name = 'msg' placeholder = 'writing.....'></textarea></td>"; 
                                  echo "<td><input type='submit' name='submit'></td>";
                            ?> 
                                </form>
                        <?php
                            }   
                        ?>       
                 <?php
                } 
            ?>   
            </thead>
            </table>
               
<?php
      }
mysqli_close($con);
?> 

              
</body>
</html>