<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Setting_Update extends CI_Controller{
	
	public function __construct(){
		parent::__construct();
		$this->load->database();
		$this->load->model('Update_model');
		$this->load->library('form_validation');
		
		// $this->load->view('header');

	}
	
	public function form(){
		$this->load->view('upload_form');
		$this->load->view('footer');
	}
	
	public function home_data(){

		//validate the form data 

		$this->form_validation->set_rules('pic_title', 'Picture Title', 'required');

        if ($this->form_validation->run() == FALSE){
			$this->load->view('admin/setting_data');
		}else{
			
			//get the form values
			$data['pic_title'] = $this->input->post('pic_title', TRUE);
			$data['pic_desc'] = $this->input->post('pic_desc', TRUE);

			// //file upload code 
			// //set file upload settings 
			// $config['upload_path']          = APPPATH. '../assests/uploads/';
			// $config['allowed_types']        = 'gif|jpg|png';
			// $config['max_size']             = 100;

			// $this->load->library('upload', $config);

			// if ( ! $this->upload->do_upload('pic_file')){
			// 	$error = array('error' => $this->upload->display_errors());
			// 	$this->load->view('admin/setting_data', $error);
			// }else{

			// 	//file is uploaded successfully
			// 	//now get the file uploaded data 
			// 	$upload_data = $this->upload->data();

			// 	//get the uploaded file name
			// 	$data['pic_file'] = $upload_data['file_name'];

				//store pic data to the db
				$this->Update_model->store_home_data($data);

				redirect('admin/Setting');
			}
			// $this->load->view('footer');
		}
	

	//-----------------------------------------------Ecosystem-----------------------------------------------------------

	public function ecosystem_data(){
		


		//validate the form data 

		$this->form_validation->set_rules('first_pic_title', 'First Picture Title', 'required');
		$this->form_validation->set_rules('second_pic_title', 'Second Picture Title', 'required');
		$this->form_validation->set_rules('third_pic_title', 'Third Picture Title', 'required');
		$this->form_validation->set_rules('fourth_pic_title', 'Fourth Picture Title', 'required');

        if ($this->form_validation->run() == FALSE){
			$this->load->view('admin/setting_data');

		}else{
			
			//get the form values
			$data['first_pic_title'] = $this->input->post('first_pic_title', TRUE);
			$data['second_pic_title'] = $this->input->post('second_pic_title', TRUE);
			$data['third_pic_title'] = $this->input->post('third_pic_title', TRUE);
			$data['fourth_pic_title'] = $this->input->post('fourth_pic_title', TRUE);
			

			//file upload code 
			//set file upload settings 
			$config['upload_path']          = APPPATH. '../assests/uploads/';
			$config['allowed_types']        = 'gif|jpg|png';
			$config['max_size']             = 1024;

				$this->load->library('upload', $config);

				if (!empty($_FILES['first_pic_file']['name'])) {
					$this->upload->do_upload('first_pic_file');
					$fileData = $this->upload->data();
			        $data['first_pic_file'] = $fileData['file_name'];
					
					}else{
						$data['first_pic_file'] = $this->input->post('first_old', TRUE);
					}
				if (!empty($_FILES['second_pic_file']['name'])) {
					$this->upload->do_upload('second_pic_file');
					$fileData = $this->upload->data();
			        $data['second_pic_file'] = $fileData['file_name'];
					
					}else{
						$data['second_pic_file'] = $this->input->post('second_old', TRUE);
					}
				if (!empty($_FILES['third_pic_file']['name'])) {
					$this->upload->do_upload('third_pic_file');
					$fileData = $this->upload->data();
			        $data['third_pic_file'] = $fileData['file_name'];
					
					}else{
						$data['third_pic_file'] = $this->input->post('third_old', TRUE);
					}
				if (!empty($_FILES['fourth_pic_file']['name'])) {
					$this->upload->do_upload('fourth_pic_file');
					$fileData = $this->upload->data();
			        $data['fourth_pic_file'] = $fileData['file_name'];
					
					}else{
						$data['fourth_pic_file'] = $this->input->post('fourth_old', TRUE);
					}			
			//   echo "<pre>";
			// print_r($data); die;
			  $this->Update_model->store_ecosystem_data($data);;
			  	redirect('admin/Setting');
						// $this->load->view('footer');
			}
		}

//------------------------------------------------Fun APP-----------------------------------------------------------

		public function fun_data(){

		//validate the form data 

		$this->form_validation->set_rules('fan_pic_title', 'Picture Title', 'required');

        if ($this->form_validation->run() == FALSE){
			$this->load->view('admin/setting_data');
		}else{
			
			//get the form values
			$data['fan_pic_title'] = $this->input->post('fan_pic_title', TRUE);
			$data['fan_pic_desc'] = $this->input->post('fan_pic_desc', TRUE);
			//file upload code 
			//set file upload settings 
			$config['upload_path']          = APPPATH. '../assests/uploads/';
			$config['allowed_types']        = 'gif|jpg|png';
			$config['max_size']             = 1024;

			$this->load->library('upload', $config);

			if (!empty($_FILES['first_pic_file']['name'])) {
					$this->upload->do_upload('first_pic_file');
					$fileData = $this->upload->data();
			        $data['first_pic_file'] = $fileData['file_name'];
					
					}else{
						$data['first_pic_file'] = $this->input->post('fan_first_old', TRUE);
					}

			if (!empty($_FILES['second_pic_file']['name'])) {
					$this->upload->do_upload('second_pic_file');
					$fileData = $this->upload->data();
			        $data['second_pic_file'] = $fileData['file_name'];
					
					}else{
						$data['second_pic_file'] = $this->input->post('fan_second_old', TRUE);
					}

			if (!empty($_FILES['third_pic_file']['name'])) {
					$this->upload->do_upload('third_pic_file');
					$fileData = $this->upload->data();
			        $data['third_pic_file'] = $fileData['file_name'];
					
					}else{
						$data['third_pic_file'] = $this->input->post('fan_third_old', TRUE);
					}

			if (!empty($_FILES['fourth_pic_file']['name'])) {
					$this->upload->do_upload('fourth_pic_file');
					$fileData = $this->upload->data();
			        $data['fourth_pic_file'] = $fileData['file_name'];
					
					}else{
						$data['fourth_pic_file'] = $this->input->post('fan_fourth_old', TRUE);
						// print_r($data);die;
					}

			}
				$this->Update_model->store_fun_app_data($data);
				
				redirect('admin/Setting');
			}
			// $this->load->view('footer');


	//-------------------------------------------------Market place------------------------------------------------

			public function market_data(){
				
					//validate the form data 

					$this->form_validation->set_rules('first_pic_title', 'Picture Title', 'required');

			        if ($this->form_validation->run() == FALSE){
						$this->load->view('admin/setting_data');
					}else{
						
						//get the form values
						$data['first_pic_title'] = $this->input->post('first_pic_title', TRUE);
						$data['first_pic_heading'] = $this->input->post('first_pic_heading',TRUE);
						$data['first_pic_desc'] = $this->input->post('first_pic_desc', TRUE);
						$data['second_pic_heading'] = $this->input->post('second_pic_heading',TRUE);
						$data['second_pic_desc'] = $this->input->post('second_pic_desc', TRUE);
						$data['third_pic_heading'] = $this->input->post('third_pic_heading',TRUE);
						$data['third_pic_desc'] = $this->input->post('third_pic_desc', TRUE);
						$data['fourth_pic_heading'] = $this->input->post('fourth_pic_heading',TRUE);
						$data['fourth_pic_desc'] = $this->input->post('fourth_pic_desc', TRUE);
						$data['fifth_pic_heading'] = $this->input->post('fifth_pic_heading',TRUE);
						$data['fifth_pic_desc'] = $this->input->post('fifth_pic_desc', TRUE);



						//file upload code 
						//set file upload settings 
						$config['upload_path']          = APPPATH. '../assests/uploads/';
						$config['allowed_types']        = 'gif|jpg|png';
						$config['max_size']             = 1024;

						$this->load->library('upload', $config);

						if (!empty($_FILES['first_pic_file']['name'])) {
								$this->upload->do_upload('first_pic_file');
								$fileData = $this->upload->data();
						        $data['first_pic_file'] = $fileData['file_name'];
								
								}else{
									$data['first_pic_file'] = $this->input->post('market_first_old', TRUE);
								}

						if (!empty($_FILES['second_pic_file']['name'])) {
								$this->upload->do_upload('second_pic_file');
								$fileData = $this->upload->data();
						        $data['second_pic_file'] = $fileData['file_name'];
								
								}else{
									$data['second_pic_file'] = $this->input->post('market_second_old', TRUE);
								}

						if (!empty($_FILES['third_pic_file']['name'])) {
								$this->upload->do_upload('third_pic_file');
								$fileData = $this->upload->data();
						        $data['third_pic_file'] = $fileData['file_name'];
								
								}else{
									$data['third_pic_file'] = $this->input->post('market_third_old', TRUE);
								}

						if (!empty($_FILES['fourth_pic_file']['name'])) {
								$this->upload->do_upload('fourth_pic_file');
								$fileData = $this->upload->data();
						        $data['fourth_pic_file'] = $fileData['file_name'];
								
								}else{
									$data['fourth_pic_file'] = $this->input->post('market_fourth_old', TRUE);
								}

						if (!empty($_FILES['fifth_pic_file']['name'])) {
								$this->upload->do_upload('fifth_pic_file');
								$fileData = $this->upload->data();
						        $data['fifth_pic_file'] = $fileData['file_name'];
								
								}else{
									$data['fifth_pic_file'] = $this->input->post('markrt_fifth_old', TRUE);
								}
						
						

							//store pic data to the db
								// echo '<pre>';
								// print_r($data);die;
							$this->Update_model->store_marketplace_data($data);

							redirect('admin/Setting');
						}
			// $this->load->view('footer');
					}

	//------------------------------------------------Data Anlaytics----------------------------------------------------------
	public function dataAnlaytics(){

		//validate the form data 

		$this->form_validation->set_rules('first_pic_title', 'Picture Title', 'required');

        if ($this->form_validation->run() == FALSE){
			$this->load->view('admin/setting_data');
		}else{
			
			//get the form values
			$data['first_pic_title'] = $this->input->post('first_pic_title', TRUE);
			$data['first_pic_heading'] = $this->input->post('first_pic_heading', TRUE);
			$data['first_pic_desc'] = $this->input->post('first_pic_desc', TRUE);
			$data['second_pic_title'] = $this->input->post('second_pic_title', TRUE);
			$data['second_pic_heading'] = $this->input->post('second_pic_heading', TRUE);
			$data['third_pic_heading'] = $this->input->post('third_pic_heading', TRUE);
			$data['third_pic_desc'] = $this->input->post('third_pic_desc', TRUE);
			$data['fourth_pic_heading'] = $this->input->post('fourth_pic_heading', TRUE);
			$data['fourth_pic_desc'] = $this->input->post('fourth_pic_desc', TRUE);
			$data['fifth_pic_heading'] = $this->input->post('fifth_pic_heading', TRUE);
			$data['fifth_pic_desc'] = $this->input->post('fifth_pic_desc', TRUE);
			//file upload code 
			//set file upload settings 
			$config['upload_path']          = APPPATH. '../assests/uploads/';
			$config['allowed_types']        = 'gif|jpg|png';
			$config['max_size']             = 1024;

			$this->load->library('upload', $config);

			if (!empty($_FILES['first_pic_file']['name'])) {
					$this->upload->do_upload('first_pic_file');
					$fileData = $this->upload->data();
			        $data['first_pic_file'] = $fileData['file_name'];
					
					}else{
						$data['first_pic_file'] = $this->input->post('data_first_old', TRUE);
					}

			if (!empty($_FILES['second_pic_file']['name'])) {
					$this->upload->do_upload('second_pic_file');
					$fileData = $this->upload->data();
			        $data['second_pic_file'] = $fileData['file_name'];
					
					}else{
						$data['second_pic_file'] = $this->input->post('data_second_old', TRUE);
					}

			if (!empty($_FILES['third_pic_file']['name'])) {
					$this->upload->do_upload('third_pic_file');
					$fileData = $this->upload->data();
			        $data['third_pic_file'] = $fileData['file_name'];
					
					}else{
						$data['third_pic_file'] = $this->input->post('data_third_old', TRUE);
					}

			if (!empty($_FILES['fourth_pic_file']['name'])) {
					$this->upload->do_upload('fourth_pic_file');
					$fileData = $this->upload->data();
			        $data['fourth_pic_file'] = $fileData['file_name'];
					
					}else{
						$data['fourth_pic_file'] = $this->input->post('data_fourth_old', TRUE);
					}
			
			}
				// echo '<pre>';
				// print_r($data);die;
				$this->Update_model->store_data_anlaytics_data($data);
				
				redirect('admin/Setting');
			}

//----------------------------------------------------Contact------------------------------------------------------------

		public function contact(){

			$this->form_validation->set_rules('first_title','First contact','required');
			if ($this->form_validation->run() == FALSE){
			$this->load->view('admin/setting_data');
			}else{

					$data['first_title'] = $this->input->post('first_title',TRUE);
					$data['first_desc'] = $this->input->post('first_desc',TRUE);

					$this->Update_model->store_contact_data($data);

					redirect('admin/Setting');
			}
		}

//----------------------------------------------------FAQ------------------------------------------------------------------
		public function faq(){

			$this->form_validation->set_rules('first_title','First contact','required');
			if ($this->form_validation->run() == FALSE){
			$this->load->view('admin/setting_data');
			}else{

					$data['first_title'] = $this->input->post('first_title',TRUE);
					$data['first_desc'] = $this->input->post('first_desc',TRUE);
					$data['second_title'] = $this->input->post('second_title',TRUE);
					$data['second_desc'] = $this->input->post('second_desc',TRUE);
					$data['third_title'] = $this->input->post('third_title',TRUE);
					$data['third_desc'] = $this->input->post('third_desc',TRUE);
					$data['fourth_title'] = $this->input->post('fourth_title',TRUE);
					$data['fourth_desc'] = $this->input->post('fourth_desc',TRUE);
					$data['fifth_title'] = $this->input->post('fifth_title',TRUE);
					$data['fifth_desc'] = $this->input->post('fifth_desc',TRUE);

					$this->Update_model->store_faq_data($data);

					redirect('admin/Setting');
			}
		}
}