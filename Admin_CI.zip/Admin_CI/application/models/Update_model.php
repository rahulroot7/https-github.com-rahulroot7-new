<?php 

class Update_model extends CI_Model{
	
	//fetch all pictures from db
	//fetch home picture from db
	function get_home_pics(){
		$all_pics = $this->db->get('home');
		return $all_pics->result();
	}
	//fetch ecosystem data from db
	function get_ecosystem_pics(){
		$all_pics = $this->db->get('ecosystem');
		return $all_pics->result();
	}
	//fetch Fan Aap data from db
	function get_fan_app_pics(){
		$all_pics = $this->db->get('fan_app');
		return $all_pics->result();
	}
	//fetch market data from db
	function get_market_pics(){
		$all_pics = $this->db->get('market_place');
		return $all_pics->result();
	}
	//fetch  data Anlaytics from db
	function get_data_pics(){
		$all_pics = $this->db->get('dataanlaytics');
		return $all_pics->result();
	}
	//fetch Contact form db
	function get_contact_pics(){
		$all_pics = $this->db->get('contact');
		return $all_pics->result();
	}
	//fetch FAQ form db
	function get_faq_pics(){
		$all_pics = $this->db->get('faq');
		return $all_pics->result();
	}





	//save picture data to db
	function store_pic_data($data){
		$update_data['pic_title'] = $data['pic_title'];
		$update_data['pic_desc'] = $data['pic_desc'];
		$update_data['pic_file'] = $data['pic_file'];

		$query = $this->db->update('pictures', $update_data);
	}


	//save Home data to db
	function store_home_data($data){
		$update_data['pic_title'] = $data['pic_title'];
		$update_data['pic_desc'] = $data['pic_desc'];
		// $update_data['pic_file'] = $data['pic_file'];
		// print_r($data);die;
		$query = $this->db->update('home', $update_data);
		// print_r($query);die;
	}

	//save ecosystem data to db
	function store_ecosystem_data($data){
        
		$update_data['first_pic_title'] = $data['first_pic_title'];
		$update_data['first_pic_file'] = $data['first_pic_file'];
		$update_data['second_pic_title'] = $data['second_pic_title'];
		$update_data['second_pic_file'] = $data['second_pic_file'];
		$update_data['third_pic_title'] = $data['third_pic_title'];
		$update_data['third_pic_file'] = $data['third_pic_file'];
		$update_data['fourth_pic_title'] = $data['fourth_pic_title'];
		$update_data['fourth_pic_file'] = $data['fourth_pic_file'];

		$query = $this->db->update('ecosystem', $update_data);
		
	}

	//save Fan data to db
	function store_fun_app_data($data){
		
		$update_data['fan_pic_title'] = $data['fan_pic_title'];
		$update_data['fan_pic_desc'] = $data['fan_pic_desc'];
		$update_data['first_pic_file'] = $data['first_pic_file'];
		$update_data['second_pic_file'] = $data['second_pic_file'];
		$update_data['third_pic_file'] = $data['third_pic_file'];
		$update_data['fourth_pic_file'] = $data['fourth_pic_file'];

		$query = $this->db->update('fan_app', $update_data);
		
	}

	//save ecosystem data to db
	function store_marketplace_data($data){
		// echo '<pre>';
		// print_r($data);die;
		$update_data['first_pic_title'] = $data['first_pic_title'];
		$update_data['first_pic_heading'] = $data['first_pic_heading'];
		$update_data['first_pic_desc'] = $data['first_pic_desc'];
		$update_data['first_pic_file'] = $data['first_pic_file'];
		$update_data['second_pic_heading'] = $data['second_pic_heading'];
		$update_data['second_pic_desc'] = $data['second_pic_desc'];
		$update_data['second_pic_file'] = $data['second_pic_file'];
		$update_data['third_pic_heading'] = $data['third_pic_heading'];
		$update_data['third_pic_desc'] = $data['third_pic_desc'];
		$update_data['third_pic_file'] = $data['third_pic_file'];
		$update_data['fourth_pic_heading'] = $data['fourth_pic_heading'];
		$update_data['fourth_pic_desc'] = $data['fourth_pic_desc'];
		$update_data['fourth_pic_file'] = $data['fourth_pic_file'];
		$update_data['fifth_pic_heading'] = $data['fifth_pic_heading'];
		$update_data['fifth_pic_desc'] = $data['fifth_pic_desc'];
		$update_data['fifth_pic_file'] = $data['fifth_pic_file'];

		$query = $this->db->update('market_place', $update_data);
		
	}

	//save Fan data to db
	function store_data_anlaytics_data($data){
		
		$update_data['first_pic_title'] = $data['first_pic_title'];
		$update_data['first_pic_heading'] = $data['first_pic_heading'];
		$update_data['first_pic_desc'] = $data['first_pic_desc'];
		$update_data['first_pic_file'] = $data['first_pic_file'];
		$update_data['second_pic_file'] = $data['second_pic_file'];
		$update_data['third_pic_file'] = $data['third_pic_file'];
		$update_data['second_pic_title'] = $data['second_pic_title'];
		$update_data['second_pic_heading'] = $data['second_pic_heading'];
		$update_data['fourth_pic_file'] = $data['fourth_pic_file'];
		$update_data['third_pic_heading'] = $data['third_pic_heading'];
		$update_data['third_pic_desc'] = $data['third_pic_desc'];
		$update_data['fourth_pic_heading'] = $data['fourth_pic_heading'];
		$update_data['fourth_pic_desc'] = $data['fourth_pic_desc'];
		$update_data['fifth_pic_heading'] = $data['fifth_pic_heading'];
		$update_data['fifth_pic_desc'] = $data['fifth_pic_desc'];

		$query = $this->db->update('dataanlaytics', $update_data);
		
	}

	//save cantact data to db
	function store_contact_data($data){
		$update_data['first_title'] = $data['first_title'];
		$update_data['first_desc'] = $data['first_desc'];

		$query = $this->db->update('contact', $update_data);
	}
	//save FAQ data in database
	function store_faq_data($data){
		$update_data['first_title'] = $data['first_title'];
		$update_data['first_desc'] = $data['first_desc'];
		$update_data['second_title'] = $data['second_title'];
		$update_data['second_desc'] = $data['second_desc'];
		$update_data['third_title'] = $data['third_title'];
		$update_data['third_desc'] = $data['third_desc'];
		$update_data['fourth_title'] = $data['fourth_title'];
		$update_data['fourth_desc'] = $data['fourth_desc'];
		$update_data['fifth_title']  = $data['fifth_title'];
		$update_data['fifth_desc']  = $data['fifth_desc'];

		$query = $this->db->update('faq',$update_data);

	}
	
}