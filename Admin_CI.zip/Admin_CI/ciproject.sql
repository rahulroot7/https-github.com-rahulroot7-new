-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 26, 2021 at 01:19 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ciproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `first_title` varchar(255) NOT NULL,
  `first_desc` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `first_title`, `first_desc`) VALUES
(1, 'Apply here for early access and partnerships!', 'Early access members get the chance to own exclusive digital assets, earn NOM coins, get access to the future of sports, before anyone else.\r\n\r\nDrop us a message and tell us why you need to join the early access group or want to partner up with us!');

-- --------------------------------------------------------

--
-- Table structure for table `dataanlaytics`
--

CREATE TABLE `dataanlaytics` (
  `id` int(11) NOT NULL,
  `first_pic_title` varchar(255) NOT NULL,
  `first_pic_heading` varchar(255) NOT NULL,
  `first_pic_desc` varchar(255) NOT NULL,
  `first_pic_file` varchar(255) NOT NULL,
  `second_pic_file` varchar(255) NOT NULL,
  `third_pic_file` varchar(255) NOT NULL,
  `second_pic_title` varchar(255) NOT NULL,
  `second_pic_heading` varchar(255) NOT NULL,
  `fourth_pic_file` varchar(255) NOT NULL,
  `third_pic_heading` varchar(255) NOT NULL,
  `third_pic_desc` varchar(255) NOT NULL,
  `fourth_pic_heading` varchar(255) NOT NULL,
  `fourth_pic_desc` varchar(255) NOT NULL,
  `fifth_pic_heading` varchar(255) NOT NULL,
  `fifth_pic_desc` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dataanlaytics`
--

INSERT INTO `dataanlaytics` (`id`, `first_pic_title`, `first_pic_heading`, `first_pic_desc`, `first_pic_file`, `second_pic_file`, `third_pic_file`, `second_pic_title`, `second_pic_heading`, `fourth_pic_file`, `third_pic_heading`, `third_pic_desc`, `fourth_pic_heading`, `fourth_pic_desc`, `fifth_pic_heading`, `fifth_pic_desc`) VALUES
(1, 'Data analytics', 'Fan insights in real time.', 'Nominees provides real time market research and data driven analytics for those who want to learn more about their fans, followers, and customers. Opinions, interests and needs, everything you need to know in one place, so you can focus on building a loya', 'ballon28.png', 'purple-box.png', 'graphic_Ecosystem12.png', 'Reward Protocol', 'Loyalty and engagement rewards for your greatest fans', 'coin-side15.png', 'More engagement, more rewards', 'Engagement and loyalty in the nominees ecosystem is directly related to getting rewarded with NOM coins. Our users (the nominators) earn NOM by actively engaging with hot sports content, interacting on our NFT marketplace, and by creating valuable insight', 'Proof of Engagement', 'Engagement and loyalty in the nominees ecosystem is directly related to getting rewarded with NOM coins. Our users (the nominators) earn NOM by actively engaging with hot sports content, interacting on our NFT marketplace, and by creating valuable insight', 'Our Products', 'Blockchain Platform\r\nLeverage blockchain technology the right way.\r\n\r\nWallet\r\nYour digital assets, safe and easily acessible.\r\n\r\nMarketplace-as-a-Service (MaaS)\r\nBuild your own collection of digital assets (NFTs) or integrate our MaaS solution.\r\n\r\nReward ');

-- --------------------------------------------------------

--
-- Table structure for table `ecosystem`
--

CREATE TABLE `ecosystem` (
  `id` int(11) NOT NULL,
  `first_pic_title` varchar(255) NOT NULL,
  `first_pic_file` varchar(255) NOT NULL,
  `second_pic_title` varchar(255) NOT NULL,
  `second_pic_file` varchar(255) NOT NULL,
  `third_pic_title` varchar(255) NOT NULL,
  `third_pic_file` varchar(255) NOT NULL,
  `fourth_pic_title` varchar(255) NOT NULL,
  `fourth_pic_file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ecosystem`
--

INSERT INTO `ecosystem` (`id`, `first_pic_title`, `first_pic_file`, `second_pic_title`, `second_pic_file`, `third_pic_title`, `third_pic_file`, `fourth_pic_title`, `fourth_pic_file`) VALUES
(6, 'first Our ecosystem', 'Play5.png', 'second Our ecosystem', 'graphic_Ecosystem2.png', 'third Our ecosystem', 'Shoe_card.png', 'forth Our ecosystem', 'shoes_Ecosystem-mob.png');

-- --------------------------------------------------------

--
-- Table structure for table `fan_app`
--

CREATE TABLE `fan_app` (
  `id` int(11) NOT NULL,
  `fan_pic_title` varchar(255) NOT NULL,
  `fan_pic_desc` varchar(255) NOT NULL,
  `first_pic_file` varchar(255) NOT NULL,
  `second_pic_file` varchar(255) NOT NULL,
  `third_pic_file` varchar(255) NOT NULL,
  `fourth_pic_file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fan_app`
--

INSERT INTO `fan_app` (`id`, `fan_pic_title`, `fan_pic_desc`, `first_pic_file`, `second_pic_file`, `third_pic_file`, `fourth_pic_file`) VALUES
(1, 'First Fan App This is area', 'On our web based fan engagement playground fans can engage and share their opinion on hottest sports content and get rewarded with NOM. Fans can redeem their rewards for digital collectibles and club passes to gain access to exclusive content and influenc', 'da-img3.png', 'Card11.png', 'graphic_Ecosystem11.png', 'Card12.png');

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `id` int(11) NOT NULL,
  `first_title` varchar(255) NOT NULL,
  `first_desc` varchar(255) NOT NULL,
  `second_title` varchar(255) NOT NULL,
  `second_desc` varchar(255) NOT NULL,
  `third_title` varchar(255) NOT NULL,
  `third_desc` varchar(255) NOT NULL,
  `fourth_title` varchar(255) NOT NULL,
  `fourth_desc` varchar(255) NOT NULL,
  `fifth_title` varchar(255) NOT NULL,
  `fifth_desc` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`id`, `first_title`, `first_desc`, `second_title`, `second_desc`, `third_title`, `third_desc`, `fourth_title`, `fourth_desc`, `fifth_title`, `fifth_desc`) VALUES
(1, 'Apply here for early access and partnerships!', 'Blockchain is the technology that allows for radically more ethical and beneficial platforms that put people at its center. Modern web infrastructures are flawed, their success is based on the value that users create, and still those big tech platforms ge', 'Pleae upload here', 'NOM is the engagement reward and platform currency (social + governance token) that fuels the nominees ecosystem. It is directly linked to a user’s activity and value on the platforms (apps, dApps, social networks), marketplaces and wallets powered by the', 'platform that enables sports organizations and fans to make mone', 'nominees is a next generation sports platform that enables sports organizations and fans to make money by selling existing media assets, be more efficient by using a ready-to-use platform and bond with each other in a rewarding and addicting way. Covid ha', 'or, contact us via hello@nominees.co or our contact form - we’ll get', 't’s as simple as uploading an image or video to your instagram account! Join our partner network as early as possible to create your own NFT collection. You choose the types of collectibles you want to sell to your audience and our platform does the heavy', 'the next generation of digital fan economies that knows no ', 'nominees is a sports ecosystem for the next generation of digital fan economies that knows no boundaries. Fans love different sports and so do we, without limitations! From football (soccer), cricket, rugby, tennis to racing or baseball - we’re empowering');

-- --------------------------------------------------------

--
-- Table structure for table `home`
--

CREATE TABLE `home` (
  `id` int(11) NOT NULL,
  `pic_title` varchar(255) NOT NULL,
  `pic_desc` varchar(255) NOT NULL,
  `pic_file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `home`
--

INSERT INTO `home` (`id`, `pic_title`, `pic_desc`, `pic_file`) VALUES
(3, 'Unleash the power of fans rahul and Amit.', 'with nominees, the new blockchain protocol and platform for sports.new style.', '');

-- --------------------------------------------------------

--
-- Table structure for table `market_place`
--

CREATE TABLE `market_place` (
  `id` int(11) NOT NULL,
  `first_pic_title` varchar(255) NOT NULL,
  `first_pic_heading` varchar(255) NOT NULL,
  `first_pic_desc` varchar(255) NOT NULL,
  `first_pic_file` varchar(255) NOT NULL,
  `second_pic_heading` varchar(255) NOT NULL,
  `second_pic_desc` varchar(255) NOT NULL,
  `second_pic_file` varchar(255) NOT NULL,
  `third_pic_heading` varchar(255) NOT NULL,
  `third_pic_desc` varchar(255) NOT NULL,
  `third_pic_file` varchar(255) NOT NULL,
  `fourth_pic_heading` varchar(255) NOT NULL,
  `fourth_pic_desc` varchar(255) NOT NULL,
  `fourth_pic_file` varchar(255) NOT NULL,
  `fifth_pic_heading` varchar(255) NOT NULL,
  `fifth_pic_desc` varchar(255) NOT NULL,
  `fifth_pic_file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `market_place`
--

INSERT INTO `market_place` (`id`, `first_pic_title`, `first_pic_heading`, `first_pic_desc`, `first_pic_file`, `second_pic_heading`, `second_pic_desc`, `second_pic_file`, `third_pic_heading`, `third_pic_desc`, `third_pic_file`, `fourth_pic_heading`, `fourth_pic_desc`, `fourth_pic_file`, `fifth_pic_heading`, `fifth_pic_desc`, `fifth_pic_file`) VALUES
(2, 'Unleash the power of market', 'This is first heading', 'Create valuable digital sports merchandise (NFTs) that sports fans love and collect, from branded jerseys to unique football shoes - with nominees there are not limits to your creativity.', 'graphic_Ecosystem-mob3.png', 'Merchandise', 'Create valuable digital sports merchandise (NFTs) that sports fans love and collect, from branded jerseys to unique football shoes - with nominees there are not limits to your creativity.', 'graphic_Ecosyste-mob6.png', 'Club Pass', 'A fan’s entry to exclusive content, voting rights and proof of exceptional fanship. Seasonal club passes (NFTs) for the die-hard fans who want to set themselves apart.', 'shoes_Ecosystem-mob2.png', 'Iconic Video Moments', 'Do you want to own or sell special moments of sports history? Tokenize, sell and showcase limited epic video moments of your club or other licensed sc', 'player-card2.png', 'Memorabilia', 'Create authentic digital memorabilia, secured by our blockchain technology. Fans can now collect and own super rare and valuable memorabilia, with provable authenticity and traceability.', 'player-card3.png');

-- --------------------------------------------------------

--
-- Table structure for table `pictures`
--

CREATE TABLE `pictures` (
  `id` int(11) NOT NULL,
  `pic_title` varchar(255) NOT NULL,
  `pic_desc` varchar(255) NOT NULL,
  `pic_file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pictures`
--

INSERT INTO `pictures` (`id`, `pic_title`, `pic_desc`, `pic_file`) VALUES
(1, 'Unleash the power of fans rahul and Amit.', 'with nominees, the new blockchain protocol and platform for sports second and new .', 'graphic_Ecosystem-mob16.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `id` int(11) NOT NULL,
  `userName` varchar(120) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`id`, `userName`, `password`) VALUES
(1, 'admin', '43e04f3b0da16d94ee5af9381a0171ec');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dataanlaytics`
--
ALTER TABLE `dataanlaytics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ecosystem`
--
ALTER TABLE `ecosystem`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fan_app`
--
ALTER TABLE `fan_app`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home`
--
ALTER TABLE `home`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `market_place`
--
ALTER TABLE `market_place`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pictures`
--
ALTER TABLE `pictures`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbladmin`
--
ALTER TABLE `tbladmin`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dataanlaytics`
--
ALTER TABLE `dataanlaytics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ecosystem`
--
ALTER TABLE `ecosystem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `fan_app`
--
ALTER TABLE `fan_app`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `home`
--
ALTER TABLE `home`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `market_place`
--
ALTER TABLE `market_place`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pictures`
--
ALTER TABLE `pictures`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbladmin`
--
ALTER TABLE `tbladmin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
