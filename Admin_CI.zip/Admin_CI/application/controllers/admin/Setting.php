<?php
defined('BASEPATH') OR exit('No direct script access allowed');
Class Setting extends CI_Controller {
function __construct(){
parent::__construct();
if(! $this->session->userdata('adid'))
redirect('admin/login');
}


	public function index()
		{
			$this->load->model('Update_model');

			$data['home_list'] = $this->Update_model->get_home_pics();
			$data['ecosystem_list'] = $this->Update_model->get_ecosystem_pics();
			$data['fan_app_list'] = $this->Update_model->get_fan_app_pics();
			$data['market_list'] = $this->Update_model->get_market_pics();
			$data['data_anlaytics_list'] = $this->Update_model->get_data_pics();
			$data['contact_list'] = $this->Update_model->get_contact_pics();
			$data['faq_list'] = $this->Update_model->get_faq_pics();
			// print_r($data['ecosystem_list']);die;
			$this->load->view('admin/setting_data', $data);
			
		}

}