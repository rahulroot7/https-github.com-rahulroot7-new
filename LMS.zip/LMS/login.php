<?php
    include 'index.php';
    session_start();

    include("config.php");

    if (isset($_POST['login'])) {
        $email    = $_POST['email'];
        $password = (md5($_POST['pass']));   
        if(!empty($email) && !empty($password)){
            $result = mysqli_query($con, "select * from student where email='$email' and pass='$password'"); 
           
            
            $user_matched = mysqli_num_rows($result);
           // print_r($user_matched);die;
            if($user_matched > 0){
                $query = mysqli_fetch_array($result);
                $admin =$query['is_admin']; 
                $_SESSION["email"] = $email;
                $_SESSION["pass"] = $password;
                    if ($admin == 1) {                    
                            header("location:stuprofile.php");
                    }else {
                             header("location: stuprofile.php");
                          }
            }else{
                    $msg = "email or password wrong";
                 }
        }else{
                $msg="required email and password";
             }
    }
         
?>

<!DOCTYPE html>
<html>

<head>
    <title>Login</title>
    <title></title>
    <link rel="stylesheet" href="css/style.css">  
</head>

<body>
    <div style="padding-left:20px">
    <h1>Student Login </h1>
    <p>online fee submit and assignment .....</p>
    <p>Some content..</p>
    <div style="padding-left:550px">
        <h2>LOG IN </h2>
        
        <form  action="login.php" method="post" enctype="multipart/form-data">
                <b><label>Email</label></b>
                <input type="text" name="email" /><br><br>
                <b><label>Password</label></b>
                <input type="password" name="pass" /><br><br>
               <input class="submit" type="submit" name="login" value="Login"> 
        </form>
    </div>
    <?php
            if(isset($msg))
            {
                echo $msg;
            }
    ?>
</div>       
</div>
</body>
</html>
</body>

