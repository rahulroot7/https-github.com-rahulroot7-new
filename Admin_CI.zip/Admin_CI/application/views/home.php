  <!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta name="keywords" content="ScrollMagic, example, scrolling, attaching, scrollbar, tween, tweenmax">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="assets/css/style.css">

    <!-- Font Awesome -->
    <link href="assets/fontawesome/css/all.css" rel="stylesheet"> <!--load all styles -->

    <title>HOME | NOMINEES</title>

  </head>
  <body>

<!-- <div style="background-color:black"> -->
    <header class="header intro" id="Home">
      <nav class="navbar navbar-expand-lg mainNavigation">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">
            <img src="assets/img/logo.svg" class="img-fluid">
          </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mainNav" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="mainNav">
              <ul class="navbar-nav ml-auto position-relative">
                <li class="nav-item active">
                  <a class="nav-link" href="#Home">Home</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#Ecosystem">Ecosystem</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#FanApp">Fan App</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#Marketplace">Marketplace</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#DataAnalytics">Data Analytics</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#Contact">Contact</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#FAQ">FAQ</a>
                </li>
                <li class="nav-item">
                  <a href="#" class="header-btn">Sign Up</a>
                </li>
              </ul>
            </div>
        </div>
      </nav>
      <div class="animated-wrapper user-experience">
        <div class="coinHeader">
          <video muted>
            <source src="assets/videos/coin_Header_frames 2.mp4" type="video/mp4">
          </video>
        </div>
      </div>
      <div class="headerContent-wrap" id="Home">
        
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div class="header-content">
                <div class="headerContent-bg"></div>
               <!--  <h2 class="main-heading">Unleash the<br> power of fans</h2>
                <h3 class="secondary-heading">With nominees, the new blockchain protocol and platform for sports.</h3> -->
  <h2>List of Pictures</h2>
  <?php if(count($home_list)){?>
    <table class="table table-bordered">
    <thead>
      <tr>
      <th>Title</th>
      <th>Description</th>
      <th>Thumbnail</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($home_list as $pic): ?>
      
      <tr>
      <td><?=$pic->pic_title;?></td>
      <td><?=$pic->pic_desc;?></td>
      <td><a href="<?=base_url().'assests/uploads/'.$pic->pic_file;?>" target="_blank"><img src="<?=base_url().'assests/uploads/'.$pic->pic_file;?>" alt="abc" width="100"></a></td>
      </tr>
    <?php endforeach ?>
    </tbody>
    </table>
    <br />
    <a href="<?=base_url().'upload/form';?>" class="btn btn-primary">Upload More</a>
  <?php } else { ?>
    <h4>No Pictures have been uploaded!. Click this button to <a href="<?=base_url().'upload/form';?>" class="btn btn-primary">upload</a></h4>            
  <?php } ?>
                
              
              </div>            
            </div>
          </div>
        </div>
      </div>
      
    </header>

    <div class="ecosystem-wrapper" id="Ecosystem">
      <div class="container">
        <div class="ecosystem-box">
          <div class="ecosystem-box-inner">
            <div class="ecosystem-link engagement">
              <div class="net-box"></div>
              <img src="assets/img/iPhone_Ecosystem.png" class="img-fluid ecosystem-link-img">
              <h5 class="ecosystem-link-title">Fan Engagement</h5>
            </div>
            <div class="ecosystem-link marketplace">
              <div class="net-box"></div>
              <img src="assets/img/shoes_Ecosystem.png" class="img-fluid ecosystem-link-img">
              <h5 class="ecosystem-link-title">Marketplace</h5>
            </div>
            <div class="ecosystem-link analytics">
              <div class="net-box"></div>
              <img src="assets/img/graphic_Ecosystem.png" class="img-fluid ecosystem-link-img">
              <h5 class="ecosystem-link-title">Data Analytics</h5>
            </div>
            <div class="ecosystem-link technology">
              <div class="net-box"></div>
              <img src="assets/img/coin_Ecosystem.png" class="img-fluid ecosystem-link-img">
              <h5 class="ecosystem-link-title">Blockchain Technology</h5>
            </div>
          </div>
          <div class="ecosystem-box-text">
            <h3 class="secondary-heading module">Our ecosystem</h3>
            <p class="module">Nominees is a sports platform for the next generation of digital fan economies, powered and secured by blockchain technology. We empower stakeholders in sports to monetize and engage with their audiences in new ways.</p>
          </div>
        </div>
      </div>
    </div>


<div class="midContent-wrapper user-experience">
  <div class="linesBG-wrapper">
    <video muted autoplay>
      <source src="assets/videos/BG_Marketplace.mp4" type="video/mp4">
    </video>
  </div>
  
  <div class="fan-engagement-wrapper" id="FanApp">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <h2 class="main-heading module">Fan Engagement Playground</h2>
            <h3 class="secondary-heading module">Become friends with your fans.</h3>
            <p class="module">On our web based fan engagement playground fans can engage and share their opinion on hottest sports content and get rewarded with NOM. Fans can redeem their rewards for digital collectibles and club passes  to gain access to exclusive content and influence thre future of their favourite club or athlete.</p>
            <a href="#" class="link pink module">Learn more ></a>
          </div>
          <div class="col-lg-6">
            <div class="fan-engagement-snipets">
              <div class="fan-engagement-snipets-inner">

                <div class="snipet-box snipet-col1 rellax" data-rellax-speed="1" data-rellax-percentage="0.5" data-rellax-zindex="1">
                  <div class="mobile-screen bar module" >
                      <img src="assets/img/bar.png" class="img-fluid">
                  </div>
                  <div class="mobile-screen league module">
                    <img src="assets/img/league.png" class="img-fluid">
                  </div>
                </div>

                <div class="snipet-box snipet-col2 rellax" data-rellax-speed="0" data-rellax-percentage="0.5" data-rellax-zindex="2">
                  <div class="mobile-screen player module">
                    <img src="assets/img/player-card.png" class="img-fluid">
                  </div>
                  <div class="mobile-screen info module">
                    <img src="assets/img/purple-box.png" class="img-fluid">
                  </div>
                </div>

                <div class="snipet-box snipet-col3 rellax" data-rellax-speed="1" data-rellax-percentage="0.5" data-rellax-zindex="1">
                  <div class="mobile-screen favourite module">
                    <img src="assets/img/green-box.png" class="img-fluid">
                  </div>
                  <div class="mobile-screen digital module">
                    <img src="assets/img/voting-fan.png" class="img-fluid">
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>



    <div class="marketplace-wrapper user-experience" id="Marketplace">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div class="animated-img-wrapper">
                <video muted autoplay>
                  <source src="assets/videos/0000.webm" type="video/webm">
                </video>
              </div>
              <div class="marketplace-content">
                <h2 class="main-heading module">Marketpalace</h2>
                <h3 class="secondary-heading module">Digital Sports Collectibles for your global fanbase</h3>
                <p class="module">Our Marketplace is the beginning of a new era for digital collectibles in sports. From tokenized merchandise, rare iconic cards to historical video moments, it has never been that easy to create, collect and trade digital assets (NFTs = non-fungible tokens). Nominees provides providable ownership, fraud protection, latest security tech, and frictionless payments. Every item traded on our marketplace can be traced back to its origin, thanks to crytographic hashes and immutables fingerprints.</p>
              </div>
              <div class="marketplace-screens">
                <div class="marketplace-screens-inner">

                  <div class="marketplace-screens-wrap">
                    <div class="marketplace-display merchandise">
                      <div class="disCard-bg "></div>
                      <div class="display-header">
                        <div class="disLogo">
                          <img src="assets/img/seller-logo.png" class="img-fluid">
                        </div>
                        <div class="disMenu">
                          <span class="disMenu-circle"></span>
                        </div>
                      </div>
                      <div class="display-Content">
                        <h5>Own Digital colletion</h5>
                        <div class="disContent-bot">
                          <div class="disContent-botInner">
                            <small>Product Name</small>
                            <small>Price: 1 NCM - 4 EUR</small>
                            <small>Avalability USD</small>
                          </div>
                          <div class="disContent-botInner">
                            <span class="dummyBtn">Buy Now</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="marketplaceDis-content">
                      <h3 class="secondary-heading">Merchandise</h3>
                      <p>Create valuable digital sports merchandise (NFTs) that sports fans love and collect, from branded jerseys to unique football shoes - with nominees there are not limit to your creativity.</p>
                    </div>
                  </div>

                  <div class="marketplace-screens-wrap">
                    <div class="marketplace-display club-pass">
                      <div class="disCard-bg"></div>
                      <div class="display-header">
                        <div class="disLogo">
                          <img src="assets/img/seller-logo.png" class="img-fluid">
                        </div>
                        <div class="disMenu">
                          <span class="disMenu-circle"></span>
                        </div>
                      </div>
                      <div class="display-Content">
                        <small>Valid: season</small>
                        <h5>Own a Digital Superfan Pass</h5>
                        <div class="disContent-bot">
                          <div class="disContent-botInner">
                            <small>Product Name</small>
                            <small>Price: 1 NCM - 4 EUR</small>
                            <small>Avalability USD</small>
                          </div>
                          <div class="disContent-botInner">
                            <span class="dummyBtn">Buy Now</span>
                          </div>
                          
                        </div>
                      </div>
                    </div>
                    <div class="marketplaceDis-content">
                      <h3 class="secondary-heading">Club Pass</h3>
                      <p>A fan’s entry to exclusive content, voting rights and proof of exceptional fanship. Seasonal club passes (NFTs) for the die-hard fans who want to set themselves apart. </p>
                    </div>
                  </div>

                  <div class="marketplace-screens-wrap">
                    <div class="marketplace-display memorabilia">
                      <div class="disCard-bg"></div>
                      <div class="display-header">
                        <div class="disLogo">
                          <img src="assets/img/seller-logo.png" class="img-fluid">
                        </div>
                        <div class="disMenu">
                          <span class="disMenu-circle"></span>
                        </div>
                      </div>
                      <div class="display-Content">
                        <h5>Own Digital Memorabilia</h5>
                        <div class="disContent-bot">
                          <div class="disContent-botInner">
                            <small>Product Name</small>
                            <small>Price: 1 NCM - 4 EUR</small>
                            <small>Avalability USD</small>
                          </div>
                          <div class="disContent-botInner">
                            <span class="dummyBtn">Buy Now</span>
                          </div>
                          
                        </div>
                      </div>
                    </div>
                    <div class="marketplaceDis-content">
                      <h3 class="secondary-heading">Memorabilia</h3>
                      <p>Create authentic digital memorabilia, secured by our blockchain technology. Fans can now collect and own super rare and valuable memorabilia, with provable authenticity and traceability.</p>
                    </div>
                  </div>

                  <div class="marketplace-screens-wrap">
                    <div class="marketplace-display iconicVideo">
                      <div class="disCard-bg"></div>
                      <div class="display-header">
                        <div class="disLogo">
                          <img src="assets/img/seller-logo.png" class="img-fluid">
                        </div>
                        <div class="disMenu">
                          <span class="disMenu-circle"></span>
                        </div>
                      </div>
                      <div class="display-Content">
                        <h5>Own a Digital Iconic Moment</h5>
                        <div class="disContent-bot">
                          <div class="disContent-botInner">
                            <small>Product Name</small>
                            <small>Price: 1 NCM - 4 EUR</small>
                            <small>Avalability USD</small>
                          </div>
                          <div class="disContent-botInner">
                            <span class="dummyBtn">Buy Now</span>
                          </div>
                          
                        </div>
                      </div>
                    </div>
                    <div class="marketplaceDis-content">
                      <h3 class="secondary-heading">Iconic Video Moments</h3>
                      <p>Do you want to own or sell special moments of sports history? Tokenize, sell and showcase limited epic video moments of your club or other licensed scenes.</p>
                    </div>
                  </div>

                </div>
              </div>

              <div class="footButtonWrapper">
                <a href="#" class="Btn btnOut-light">Create your own NFT</a>
              </div>

            </div>
          </div>
        </div>
    </div>
</div>

    <div class="data-analytics-wrapper" id="DataAnalytics">
      <div class="container-fluid p-0">
        <div class="analytics-wrapper">
          <div class="row m-0">
            <div class="col-md-7">
              <div class="analytics-wrapper-content">
                <h2 class="main-heading">Data analytics</h2>
                <h3 class="secondary-heading">Fan insights in real time.</h3>
                <p>Nominees provides real time market research and data driven analytics for those who want to lear more about their fans, followers, and customers. Opinions, interests and needs, everything you need to know in one place, so you can focus on building a loyal fanbase and making money!</p>
                <a href="#" class="link pink">Create your survey ></a>
              </div>
            </div>
            <div class="col-md-5 pr-0">
              <div class="data-analytics-boxs">
                <div class="data-analytics-box jerseyWrap-box module">
                  <div class="data-analytics-inner jerseyWrap">
                    <img src="assets/img/jersey.png" class="img-fluid">
                  </div>                
                </div>
                <div class="data-analytics-box quarterWrap-box module">
                  <div class="data-analytics-inner quarterWrap">
                    <img src="assets/img/quarter.png" class="img-fluid">
                  </div>
                </div>
                <div class="data-analytics-box ballonWrap-box module">
                  <div class="data-analytics-inner ballonWrap">
                    <img src="assets/img/ballon.png" class="img-fluid">
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
        

        <div class="protocol-wrapper">
          <div class="container">
            
          
          <div class="row">
            <div class="col-md-12">
              <div class="protocolHeader">
                <h2 class="main-heading">Reward Protocol</h2>
                <h3 class="secondary-heading">Loyalty and engagement rewards for your greatest fans</h3>
              </div>
              <div class="protocolCoin">
                <video muted loop autoplay>
                  <source src="assets/videos/Coin_side.mp4" type="video/mp4">
                </video>
              </div>
              <div class="protocol-cols">
                <div class="row">
                  <div class="col-md-4">
                    <div class="protocol-cols-inner">
                      <h6 class="mb-4">More engagement, more rewards</h6>
                      <p>Engagement and loyalty in the nominees ecosystem is directly related to getting rewarded with NOM coins. Our users (the 
                        nominators) earn NOM by actively engaging with hot sports content, interacting on our NFT marketplace, and by creating valuable insights that help shape the future of sports. Finally, fans receive the appreciation and influence in sports they deserve!</p>
                    </div>                    
                  </div>

                  <div class="col-md-4">
                    <div class="protocol-cols-inner">
                      <h6 class="mb-4">Proof of Engagement</h6>
                      <p>The nominees protocol is designed to reward participants at multiple levels, from sports enthusiasts on the nominees platform to users of other popular sports apps. We’re building a unique incentive mechanism on top of the Phantasma Chain (phantasma.io) that is not only powering nominees, but every other community that integrates our smart reward system. Contact us if you want to learn more about our protocol.</p>
                    </div>
                  </div>

                  <div class="col-md-4">
                    <div class="protocol-cols-inner mw-100">
                      <h6 class="mb-4">Our Products</h6>
                      <ul class="protocol-cols-list">
                        <li class="protocol-cols-item"><h6>Blockchain Platform</h6>
                        <p>Leverage blockchain technology the right way.</p>
                      </li>
                        <li class="protocol-cols-item">
                          <h6>Wallet</h6>
                          <p>Your digital assets, safe and easily acessible.</p>
                        </li>
                        <li class="protocol-cols-item">
                          <h6>Marketplace-as-a-Service (MaaS)</h6>
                          <p>Build your own collection of digital assets (NFTs) or integrate our MaaS solution.</p>
                        </li>
                        <li class="protocol-cols-item">
                          <h6>Reward Tokens</h6>
                          <p>Automated reward distribition to those who really earn them.</p>
                        </li>
                      </ul>
                      <a href="#" class="link pink">Our whitepaper is coming soon!</a>                    

                    </div>
                  </div>
                </div>
              </div>
            </div>            
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="footButtonWrapper">
                <a href="#" class="Btn btnOut-light">Learn more</a>
              </div>
            </div>
          </div>
          </div>
        </div>
        
      </div>
    </div>


    <div class="nomineesFanClub-wrapper">
      <div class="container-fluid p-0">
        <div class="row mx-0">
          <div class="col-md-12 p-0">
            <div class="nomineesFanClub-inner">
              <div class="NomineesTxt">nominees</div>
              <div class="forTxt">for</div>
              <div class="fansClubTxt">fans clubs athletes eSports rights holders brands sports</div>
            </div>
          </div> 
        </div>
      </div>
    </div>

    <div class="applyForm-wrapper" id="Contact">
      <div class="container">
        <div class="applyForm-wrapper-inner">
          <div class="row">
            <div class="col-md-6">
              <div class="applyText-box">
                <h3 class="secondary-heading">Apply here for<br> early access and<br> partnerships!</h3>
                <p>Early access members get the chance to own exclusive digital assets, earn NOM coins, get access to the future of sports, before anyone else.</p>
                <p>Drop us a message and tell us why you need to join the early access group or want to partner up with us!</p>
              </div>
            </div>
            <div class="col-md-6">
              <div class="applyForm-box">
                <form>
                  <div class="form-group">
                    <input type="text" class="form-control InputStyle" id="" placeholder="Name">
                  </div>
                  <div class="form-group">
                    <input type="text" class="form-control InputStyle" id="" placeholder="Name of Organization (Optional)">
                  </div>
                  <div class="form-group">
                    <input type="email" class="form-control InputStyle" id="" placeholder="e-mail">
                  </div>
                  <div class="form-group">
                    <input type="text" class="form-control InputStyle" id="" placeholder="Phone (Optional)">
                  </div>
                  <select class="form-control InputStyle">
                    <option>What are you moste interested in?</option>
                    <option>option 1</option>
                    <option>option 2</option>
                    <option>option 3</option>
                  </select>
                  <div class="form-group">
                    <textarea class="form-control InputStyle" id="" rows="3" placeholder="Tell us why you want to join our early access group or become a nominees partner!"></textarea>
                  </div>
                  <button type="submit" class="Btn btn-outline-dark">Submit</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


    <div class="faq-wrapper" id="FAQ">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1 class="main-heading text-center">FAQ</h1> 
            <div id="accordion" class="faqAccordion">
              <div class="card">
                <div class="card-header" id="headingOne">
                  <h5 class="mb-0">
                    <button class="btn btn-link" data-toggle="collapse" data-target="#faq-1" aria-expanded="false" aria-controls="faq-1">Why are you using blockchain Technology?</button>
                  </h5>
                </div>

                <div id="faq-1" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                  <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                  </div>
                </div>
              </div>
              <div class="card">
                <div class="card-header" id="headingTwo">
                  <h5 class="mb-0">
                    <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#faq-2" aria-expanded="false" aria-controls="faq-2">What does NOM means?</button>
                  </h5>
                </div>
                <div id="faq-2" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                  <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                  </div>
                </div>
              </div>
              <div class="card">
                <div class="card-header" id="headingThree">
                  <h5 class="mb-0">
                    <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#faq-3" aria-expanded="false" aria-controls="faq-3">How can I buy items in the marketplace?</button>
                  </h5>
                </div>
                <div id="faq-3" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                  <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                  </div>
                </div>
              </div>
              <div class="card">
                <div class="card-header" id="headingThree">
                  <h5 class="mb-0">
                    <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#faq-4" aria-expanded="false" aria-controls="faq-4">What is an NFT?</button>
                  </h5>
                </div>
                <div id="faq-4" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                  <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                  </div>
                </div>
              </div>
              <div class="card">
                <div class="card-header" id="headingThree">
                  <h5 class="mb-0">
                    <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#faq-5" aria-expanded="false" aria-controls="faq-5">What kind of sports does nominees cover?</button>
                  </h5>
                </div>
                <div id="faq-5" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                  <div class="card-body">
                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <footer class="mainFooter">
      <div class="container-fluid">
        <div class="footerCols">
          <div class="footerCols-inner">
            <a href="#"><img src="assets/img/logo.png"/></a>
          </div>
          <div class="footerCols-inner">
            <h6 class="footerHeading">Categories</h6>
            <ul class="footerMenu-list">
              <li class="footerMenu-item">
                <a href="#" class="footerMenu-link">Home</a>
              </li>
              <li class="footerMenu-item">
                <a href="#" class="footerMenu-link">fan App</a>
              </li>
              <li class="footerMenu-item">
                <a href="#" class="footerMenu-link">Marketplace</a>
              </li>
              <li class="footerMenu-item">
                <a href="#" class="footerMenu-link">Data Analytics</a>
              </li>
              <li class="footerMenu-item">
                <a href="#" class="footerMenu-link">Protocol</a>
              </li>
              <li class="footerMenu-item">
                <a href="#" class="footerMenu-link">Contact</a>
              </li>
              <li class="footerMenu-item">
                <a href="#" class="footerMenu-link">FAQ</a>
              </li>
            </ul>
          </div>
          <div class="footerCols-inner">
            <h6 class="footerHeading">Community</h6>
            <p>Dear Community and future nominators,</p>
            <p>Nominees is a community driven ecosystem that aims at giving more power to the most important stake holders in sports - Fans. If you want to support our vision by collaborating (sports/tech/media), creating NFTs on our marketplace or by growing our network, please don't hesitate to get in touch with us via email or our contact form.</p>
            <p>Nominees Team</p>
            <a href="mailto:hello@nominees.co" class="footer-link">hello@nominees.co</a>
          </div>
          <div class="footerCols-inner JoinForm-wrapper">
            <div class="partWrap">
              <h6 class="footerHeading">Partners</h6>
              <div class="partWrap-inner">
                <img src="assets/img/phantasma-chain.png">
                <img src="assets/img/curise.png">
              </div>              
            </div>
            <div class="followWap">
              <h6 class="footerHeading">Follow us</h6>
              <ul class="followList">
                <li class="followItem">
                  <a href="#" class="followLink"><i class="fab fa-facebook-f"></i></a>
                </li>
                <li class="followItem">
                  <a href="#" class="followLink"><i class="fab fa-instagram"></i></a>
                </li>
                <li class="followItem">
                  <a href="#" class="followLink"><i class="fab fa-twitter"></i></a>
                </li>
                <li class="followItem">
                  <a href="#" class="followLink"><i class="fab fa-youtube"></i></a>
                </li>
              </ul>
            </div>
            <div class="JoinForm-box">
              <form>
                  <div class="form-group JoinForm-inner">
                    <input type="email" class="form-control" id="" aria-describedby="emailHelp" placeholder="Your email">
                    <button type="submit" class="btn btn-join">Join</button>
                  </div>          
              </form>
            </div>
          </div>
        </div>
      </div>
    </footer>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <script src="assets/js/script.js"></script>
    <script src="rellax-master/rellax.min.js"></script>



    <script src="https://cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.8/ScrollMagic.min.js" integrity="sha512-8E3KZoPoZCD+1dgfqhPbejQBnQfBXe8FuwL4z/c8sTrgeDMFEnoyTlH3obB4/fV+6Sg0a0XF+L/6xS4Xx1fUEg==" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.8/plugins/animation.gsap.min.js" integrity="sha512-5/OHwmQzDSBS0Ous4/hlYoWLHd06/d2r7LdKZQVBXOA6PvOqWVXtdboiLTU7lQTGyVoKVTNkwi0ol4gHGlw5ww==" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.8/plugins/debug.addIndicators.min.js" integrity="sha512-RvUydNGlqYJapy0t4AH8hDv/It+zKsv4wOQGb+iOnEfa6NnF2fzjXgRy+FDjSpMfC3sjokNUzsfYZaZ8QAwIxg==" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/2.1.3/TweenMax.min.js" integrity="sha512-DkPsH9LzNzZaZjCszwKrooKwgjArJDiEjA5tTgr3YX4E6TYv93ICS8T41yFHJnnSmGpnf0Mvb5NhScYbwvhn2w==" crossorigin="anonymous"></script>





  <script>
    var rellax = new Rellax('.rellax');
    center:true
  </script>



  <script>
    
    // Scroll video animations


  const intro = document.querySelector(".intro");
  const bg_header = intro.querySelector(".BG_header");
  const text = intro.querySelector(".header-content");
  //const coin_header  = intro.querySelector(".COIN_header");

  //END SECTION

  const controller = new ScrollMagic.Controller();

  let scene = new ScrollMagic.Scene({
    duration: 1000,
    triggerElement: intro,
    triggerHook: 0
  })

   .addIndicators()
   .setPin(intro)
   .addTo(controller);


// text animation

// const textAnim = TweenMax.fromTo(text, 8, {opacity: 1}, {opacity: 0});

  let scene2 = new ScrollMagic.Scene({
    duration: 3000,
    triggerElement: intro,
    triggerHook: 0
  })

  .setTween(textAnim)
  addTo(controller);

   // Video animation

   // let accelamount = 0.1;
   // let scrollpos   = 0;
   // let delay = 0;
   

   // scene.on('update', e => {
   //  scrollpos = e.scrollPos * 0.01;
   //  console.log(e);
   // })

   // setInterval(() => {            

   //  delay += (scrollpos - delay) * accelamount;
   //    console.log(delay);
   //  bg_header.currentTime = delay;
   // }, 33.3);


  </script>

<script>
  
  jQuery(function() {

      var coinHeader = jQuery(".animated-wrapper");
      var coinHeaderContent = jQuery(".header-content");
      jQuery(window).scroll(function() {
          var scroll = jQuery(window).scrollTop();

          if (scroll >= 600) {
              coinHeader.addClass("hide");
              coinHeaderContent.addClass("show");
          } else {
              // coinHeader.removeClass("hide");
              // coinHeaderContent.removeClass("show");
          }
      });
  });

</script>


<script>
  
  var player = $('video');
  var hasReachedUserExperience = false;

  function isInView(elem){
      return $(elem).offset().top - $(window).scrollTop() < $(elem).height();
  }

  $(window).scroll(function() {

      if (isInView($('.user-experience')) && !hasReachedUserExperience) {
          hasReachedUserExperience = true;
          player.get(0).play();
      }

  });
</script>





  </body>
</html>